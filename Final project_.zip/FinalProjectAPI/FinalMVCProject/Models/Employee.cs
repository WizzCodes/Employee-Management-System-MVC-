﻿using System.ComponentModel.DataAnnotations;


namespace FinalMVCProject.Models
{
    public class Employee
    {
            public IFormFile Image { get; set; }
            public int Id { get; set; }
            [Required]
            public string Name { get; set; }
            [Required]

            public string Email { get; set; }
            [Required]
            public string Mobile { get; set; }
            public string Gender { get; set; }
            public DateTime DateOfBirth { get; set; }

            public string Technology { get; set; }
            public string MaritalStatus { get; set; }

            public bool IsMarried { get; set; }
            [Required]

            public string Address { get; set; }
            public string PhotoPath { get; set; }

        }
    }
