﻿using FinalMVCProject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Text;

namespace FinalMVCProject.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {

        HttpClient client = new HttpClient();
        private readonly ILogger<HomeController> _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [AllowAnonymous]
     
            public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

        public async Task<IActionResult> EmployeesDetails()
        {

            var response = await client.GetAsync("http://localhost:5225/api/EmpAPI/GetEmployeesData");

            if (response.IsSuccessStatusCode)
            {
                var emps = await response.Content.ReadFromJsonAsync<List<Employee>>();
                return View(emps);
            }
            else
            {
                return View("Error");
            }
        }

        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddEmployee(Employee model)
        {
            if (model.IsMarried)
            {
                model.MaritalStatus = "Married";
            }
            else
            {
                model.MaritalStatus = "UnMarried";
            }

            model.PhotoPath = await UploadImg(model);
            if (model.PhotoPath != "Error")
            {
                var response = await client.PostAsJsonAsync("http://localhost:5225/api/EmpAPI/AddEmployeesData", model);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("EmployeesDetails");
                }
                else
                {
                    return View("Error");
                }
            }
            else
            {
                return View("Error");
            }
        }


        public async Task<IActionResult> EditData(int id)
        {
            var response = await client.GetAsync($"http://localhost:5225/api/EmpAPI/GetDataById?id={id}");


            if (response.IsSuccessStatusCode)
            {
                var employee = await response.Content.ReadFromJsonAsync<Employee>();
                return View("AddEmployee", employee);
            }
            else
            {
                return NotFound();
            }

        }


        public async Task<string> UploadImg(Employee model)
        {
            string ImageCode = model.Name + model.Mobile;

            using MultipartFormDataContent multipartContent = new();
            //multipartContent.Add(new StringContent(ImageCode, Encoding.UTF8, MediaTypeNames.Text.Plain), "ImageCode");
            var imageContent = new StreamContent(model.Image.OpenReadStream());

            imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse(MediaTypeNames.Image.Jpeg);

            multipartContent.Add(imageContent,"Image", model.Image.Name);

            var response = await client.PostAsync($"http://localhost:5225/api/EmpAPI/UploadImage?ImageCode={ImageCode}", multipartContent);
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();

                return responseContent;
            }
            else return "Error";
        }


        public async Task<IActionResult> Delete(int id)
        {
            var response = await client.DeleteAsync($"http://localhost:5225/api/EmpAPI/DeleteEmployeeData?id={id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("EmployeesDetails");
            }
            return View("Error");
        }
    }
}