using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using FinalMVCProject.Data;
using FinalMVCProject.Areas.Identity.Data;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("FinalMVCProjectContextConnection") ?? throw new InvalidOperationException("Connection string 'FinalMVCProjectContextConnection' not found.");

builder.Services.AddDbContext<FinalMVCProjectContext>(options => options.UseSqlServer(connectionString));

builder.Services.AddDefaultIdentity<FinalMVCProjectUser>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<FinalMVCProjectContext>();

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.MapRazorPages();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
