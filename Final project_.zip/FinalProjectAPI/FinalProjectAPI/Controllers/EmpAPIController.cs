﻿using FinalProjectAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpAPIController : ControllerBase
    {
        private readonly IWebHostEnvironment _environment;

        private readonly ApplicationDbcontext _db;

        public EmpAPIController(IWebHostEnvironment environment, ApplicationDbcontext dbcontext)
        {
            this._environment = environment;
            this._db = dbcontext;

        }

        [HttpPost("UploadImage")]
        public async Task<IActionResult> UploadImage(string ImageCode, IFormFile Image)
        {
            try
            {
                string FileRoot = this._environment.WebRootPath + "\\Upload";
                if (!System.IO.Directory.Exists(FileRoot))
                {
                    System.IO.Directory.CreateDirectory(FileRoot);
                }
                string imagepath = FileRoot + "\\" + ImageCode + ".png";
                if (System.IO.File.Exists(imagepath))
                {
                    System.IO.File.Delete(imagepath);
                }
                using (FileStream stream = System.IO.File.Create(imagepath))
                {
                    await Image.CopyToAsync(stream);
                    string hosturl = $"{this.Request.Scheme}://{this.Request.Host}/{this.Request.PathBase}";
                    string Imageurl = hosturl + "Upload/" + ImageCode + ".png";
                    return Ok(Imageurl);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("AddEmployeesData")]
        public async Task<IActionResult> AddEmp(Employee emp)
        {
            try
            {
                if (emp.Id == 0)
                {
                    _db.Employees.Add(emp);
                    await _db.SaveChangesAsync();
                    return Ok("Data Added Successfully");
                }
                else
                {
                    _db.Employees.Update(emp);
                    await _db.SaveChangesAsync();
                    return Ok("Data Edited Successfully");
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        [HttpGet("GetEmployeesData")]
        public async Task<IActionResult> GetEmployees()
        {
            try
            {
                var result = await _db.Employees.ToListAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetDataById")]
        public async Task<IActionResult> GetDataById(int id)
        {
            var res = await _db.Employees.FirstOrDefaultAsync(m => m.Id == id);
            if (res != null)
            {
                return Ok(res);
            }
            return NotFound();
        }

        [HttpDelete("DeleteEmployeeData")]
        public async Task<IActionResult> DeleteEmp(int id)
        {
            try
            {
                var employee = await _db.Employees.Where(m => m.Id == id).FirstOrDefaultAsync();
                if (employee == null)
                {
                    return NotFound("Employee Details Not Found");
                }
                else
                {
                    _db.Employees.Remove(employee);
                    await _db.SaveChangesAsync();
                }

                string ImageCode = employee.Name + employee.Mobile;

                string FileRoot = this._environment.WebRootPath + "\\Upload" ;
                string imagepath = FileRoot + "\\" + ImageCode + ".png";
                if (System.IO.File.Exists(imagepath))
                {
                    System.IO.File.Delete(imagepath);
                    return Ok("pass");
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}