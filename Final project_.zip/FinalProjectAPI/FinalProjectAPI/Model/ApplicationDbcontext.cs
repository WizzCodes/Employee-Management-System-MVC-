﻿using FinalProjectAPI.Model;
using Microsoft.EntityFrameworkCore;


namespace FinalProjectAPI.Model
{
    public class ApplicationDbcontext : DbContext
    {
        public ApplicationDbcontext(DbContextOptions<ApplicationDbcontext>options) :base(options){ }

        public DbSet<Employee> Employees { get; set; }
      
    }
}


